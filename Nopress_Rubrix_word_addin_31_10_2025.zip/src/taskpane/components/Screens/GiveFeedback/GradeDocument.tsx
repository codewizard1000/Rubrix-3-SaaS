import React, { useState } from "react";
import {
    Box,
    Typography,
    Paper,
    Button,
    TextField,
    Divider,
    Stack,
    Tooltip,
    IconButton,
} from "@mui/material";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import UploadFileIcon from "@mui/icons-material/UploadFile";
import AutoFixHighIcon from "@mui/icons-material/AutoFixHigh";
import { getDocumentText, insertGradeAtTop } from "../../../Utils/documentUtils";
import Loader from "../../loader/Loader";
import { analyzeRubricFile, gradeDocumentAI } from "../../../Services/gradeAi";
import Toast from "../../Toast/ToastMessage";

export default function GradeDocumentUI({ onBack }) {
    const [rubricFile, setRubricFile] = useState(null);
    const [manualCriteria, setManualCriteria] = useState("");
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [success, setSuccess] = useState(null);
    const [info, setInfo] = useState(null);

    const handleFileUpload = (e) => {
        setRubricFile(e.target.files[0]);
    };

    const handleGrade = async () => {
        setLoading(true);
        try {
            const documentText = await getDocumentText();
            if (!documentText) {
                setInfo("Document is empty. Please write something first.");
                setLoading(false);
                return
            }

            if (rubricFile) {
                analyzeRubricFile(rubricFile, async (rubricSummary, error) => {
                    if (error) {
                        console.error("Rubric Analysis Error:", error);
                        return;
                    }

                    await gradeDocumentAI(documentText, rubricSummary, manualCriteria, async (result, error) => {

                        if (error) {
                            console.error("Grading Error:", error);
                            return;
                        }

                        await insertGradeAtTop(result);
                        setLoading(false);
                    setRubricFile(null)
                    setSuccess("Document graded succesfull.");
                    });
                });

            } else {
                console.log("No rubric file uploaded, using manual criteria only.");
                // No file uploaded, just use manual criteria
                await gradeDocumentAI(documentText, null, manualCriteria, async (result, error) => {
                    
                    if (error) {
                        console.error("Grading Error:", error);
                        return;
                    }
                    await insertGradeAtTop(result);
                    setLoading(false);
                    setRubricFile(null)
                    setSuccess("Document graded succesfull.");
                });
            }
        } catch (err) {
            setLoading(false);
            console.error("Error during grading process:", err);
        }
    }

    return (
        <Box
            sx={{
                p: 2,
            }}
        >
            <Tooltip title="Back" arrow>
                <IconButton
                    onClick={onBack}
                    size="small"
                    sx={{
                        position: "fixed",
                        top: "70px",
                        left: 16,
                        color: "#64748b",
                        backgroundColor: "rgba(255,255,255,0.7)",
                        boxShadow: "0 2px 10px rgba(0,0,0,0.1)",
                        "&:hover": { backgroundColor: "rgba(0,0,0,0.05)", transform: "translateY(-1px)" },
                    }}
                >
                    <ArrowBackIcon sx={{ fontSize: 18 }} />
                </IconButton>
            </Tooltip>

            <Typography
                variant="h5"
                fontWeight={700}
                sx={{
                    color: "#0f172a",
                    mb: 1,
                    textAlign: "center",
                    fontFamily: "Poppins, sans-serif",
                    fontSize: { xs: "1.25rem", sm: "1.4rem" },
                }}
            >
                AI Grade Document
            </Typography>

            <Typography
                variant="body2"
                sx={{
                    color: "#475569",
                    textAlign: "center",
                    mb: 2,
                    lineHeight: 1.6,
                    fontSize: { xs: "0.8rem", sm: "0.9rem" },
                }}
                textAlign="center"
            >
                Upload a grading rubric or type your grading criteria manually. The AI will
                evaluate the document and insert the grad
                e summary at the top.
            </Typography>

            <Paper
                variant="outlined"
                sx={{
                    p: 1.2,
                    borderRadius: 2,
                    backgroundColor: "#f8fafc",
                    mb: 1.5,
                }}
            >
                <Typography
                    variant="subtitle2"
                    fontWeight={600}
                    sx={{ fontSize: "0.85rem", mb: 0.5 }}
                >
                    Upload Rubric (optional)
                </Typography>
                <Box sx={{ display: "flex", justifyContent: "center" }}>
                    <Button
                        component="label"
                        startIcon={<UploadFileIcon sx={{ fontSize: 18 }} />}
                        sx={{
                            mt: 0.5,
                            color: "#2563eb",
                            fontSize: "0.75rem",
                            textTransform: "capitalize",
                            py: 0.4,
                        }}
                    >
                        Upload PDF
                        <input
                            hidden
                            accept=".pdf"
                            type="file"
                            onChange={handleFileUpload}
                        />
                    </Button>
                </Box>
                {rubricFile && (
                    <Typography sx={{ fontSize: "0.75rem", mt: 0.4 }}>
                        Uploaded: {rubricFile.name}
                    </Typography>
                )}
            </Paper>

            <Divider sx={{ my: 1.5, fontSize: "0.8rem" }}>OR</Divider>

            {/* === MANUAL CRITERIA === */}
            <Paper
                variant="outlined"
                sx={{
                    p: 1.2,
                    borderRadius: 2,
                    backgroundColor: "#f8fafc",
                }}
            >
                <Typography
                    variant="subtitle2"
                    fontWeight={600}
                    sx={{ fontSize: "0.85rem", mb: 0.4 }}
                >
                    Enter Grading Standards
                </Typography>
                <TextField
                    fullWidth
                    multiline
                    minRows={3}
                    placeholder="e.g. Clarity (25%), Grammar (20%), Argument Strength (30%)..."
                    value={manualCriteria}
                    onChange={(e) => setManualCriteria(e.target.value)}
                    sx={{
                        mt: 0.5,
                        "& .MuiInputBase-input": { fontSize: "0.8rem", },
                    }}
                />
            </Paper>

            {/* === GENERATE BUTTON === */}
            <Button
                fullWidth
                variant="contained"
                disabled={!rubricFile && !manualCriteria}
                sx={{
                    mt: 2,
                    py: 0.9,
                    borderRadius: 2,
                    fontSize: "0.8rem",
                    background: "linear-gradient(135deg, #7c3aed, #2563eb)",
                    textTransform: "capitalize",
                }}
                startIcon={<AutoFixHighIcon sx={{ fontSize: 18 }} />}
                onClick={handleGrade}
            >
                Generate Grade
            </Button>

            {loading && <Loader />}
            {error && (
                <Toast
                    error={error}
                    onClose={() => setError(null)}
                />
            )}
            {info && (
                <Toast
                    info={info}
                    onClose={() => setInfo(null)}
                />
            )}
            {success && (
                <Toast
                    success={success}
                    onClose={() => setSuccess(null)}
                />
            )}
        </Box>
    );
}
